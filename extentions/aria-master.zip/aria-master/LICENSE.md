All documents in this Repository are licensed by contributors
under the 
[W3C Document License](https://www.w3.org/Consortium/Legal/copyright-documents).


# Code of Conduct

All code and communication in this repository are covered by the
[W3C Code of Ethics and Professional Conduct](https://www.w3.org/Consortium/cepc/).

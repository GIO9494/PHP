package com.burguer.manrique.restabar.Interfaces;

/**
 * Created by onbh4 on 09/12/2017.
 */

public interface ClickListener { void onPositionClicked(int position); void onLongClicked(int position); } 
